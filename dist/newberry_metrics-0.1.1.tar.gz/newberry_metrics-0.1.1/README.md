# Newberry Metrics

A Python package for tracking and estimating AI model token costs and usage metrics.

## Latest Version: 0.1.0

## Features

### Cost Tracking and Estimation
- Model cost calculation per million tokens
- Prompt cost estimation
- Session-based cost tracking
- Support for multiple AI models from bedrock:
  - Amazon Nova Pro
  - Amazon Nova Micro
  - Claude 3 Sonnet
  - Claude 3 Haiku
  - Llama2 13B
  - Llama2 70B

## Installation

```bash
pip install newberry_metrics
```

## Usage Examples

- **Initialize TokenEstimator**
```python
from newberry_metrics import TokenEstimator

estimator = TokenEstimator(
    model_id="amazon.nova-pro-v1:0",
    aws_access_key_id="YOUR_AWS_ACCESS_KEY_ID",
    aws_secret_access_key="YOUR_AWS_SECRET_ACCESS_KEY",
    region="us-east-1"
)
```

- **Get Model Cost per Million Tokens**
```python
costs = estimator.get_model_cost_per_million()
print(f"Input cost per million: ${costs['input']}")
print(f"Output cost per million: ${costs['output']}")
```

- **Calculate Prompt Cost**
```python
# Invoke the model to get a response object
response = estimator._invoke_bedrock("What is the weather in San Francisco?")

# Calculate cost based on the response object obtained by invoking the bedrock model
result = estimator.calculate_prompt_cost(response)
print(f"Total cost: ${result['cost']}")
print(f"Input tokens: {result['input_tokens']} (cost: ${result['input_cost']})")
print(f"Output tokens: {result['output_tokens']} (cost: ${result['output_cost']})")
print(f"Answer: {result['answer']}")
```

- **Track Session Costs**
```python
session_id = "session_1"
session_info = estimator.track_session_cost(session_id, response)
print(f"Cumulative session cost: ${session_info['session_cost']}")
print(f"Current query cost: ${session_info['current_cost']}")
```

- **Session Management**
```python
# Get cost for a specific session
session_cost = estimator.get_session_cost("session_1")

# Reset cost for a specific session
estimator.reset_session_cost("session_1")

# Reset all session costs
estimator.reset_all_session_costs()
```

## Technical Details


## Recent Updates (v0.1.0)

### New Features
- Separated AWS API invocation from response processing
- Improved response handling and error management
- Added session management functions
- Enhanced cost tracking with separate input/output calculations

### Technical Improvements
- Better code organization with separate response processing
- Improved error handling for API responses
- More efficient session cost tracking
- Better separation of concerns in the codebase

## Requirements
- Python >= 3.10
- `boto3` for AWS Bedrock integration

## Contact & Support
- **Developer**: Satya-Holbox, Harshika-Holbox
- **Email**: satyanarayan@holbox.ai
- **GitHub**: [SatyaTheG](https://github.com/SatyaTheG)

## License
This project is licensed under the MIT License.

---

**Note**: This package is actively maintained and regularly updated with new features and model support.
