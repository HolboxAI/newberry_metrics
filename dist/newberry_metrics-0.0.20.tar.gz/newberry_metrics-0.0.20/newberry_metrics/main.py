def cost():
    return ("3.5 per million tokens")